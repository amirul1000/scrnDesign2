import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MatchspeedPage } from './matchspeed';

@NgModule({
  declarations: [
    MatchspeedPage,
  ],
  imports: [
    IonicPageModule.forChild(MatchspeedPage),
  ],
})
export class MatchspeedPageModule {}
