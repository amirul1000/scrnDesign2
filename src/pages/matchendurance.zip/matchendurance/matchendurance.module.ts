import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MatchendurancePage } from './matchendurance';

@NgModule({
  declarations: [
    MatchendurancePage,
  ],
  imports: [
    IonicPageModule.forChild(MatchendurancePage),
  ],
})
export class MatchendurancePageModule {}
